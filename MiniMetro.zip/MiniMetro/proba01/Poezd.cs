﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace proba01
{
    class Poezd: Metro
    {
        public Color cline;
        public int passengers;
        public int maxpas;
        public int size;
        public byte index;
        int mv;
        PointF startP; 
        PointF endP;
        public bool t = true;
        PointF startPrev, endPrev;
        public bool Prijehal = false;
        Point csPr; Point cePr;
        public PointF location;
        public bool jezdanazd = false;
        public Point[] points = new Point[2];
        public Poezd(Color c, Color cL, byte ind)
        {
            passengers = 0;
            size = 15;
            maxpas = 20;
            clr = c;
            cline = cL;
            index = ind;
        }
        public void draw(Point sPr, Point ePr)
        {
            if (t)
            {
                startP = new Point(sPr.X, sPr.Y);
                endP = new Point(sPr.X, sPr.Y);
                csPr = new Point(sPr.X, sPr.Y);
                cePr = new Point(ePr.X, ePr.Y);
                t = false;
            }
            float distance = (float)Math.Sqrt(Math.Pow(cePr.X - csPr.X, 2) + Math.Pow(cePr.Y - csPr.Y, 2));
            if (distance > mv)
            {
                g.DrawLine(new Pen(bclr, 7), startPrev, endPrev);
                g.DrawLine(new Pen(cline), startPrev, endPrev);
                mv += size;
                g.DrawLine(new Pen(clr, 7), startP, endP);
                location = ePr;
                startPrev = startP;
                endPrev = endP;
                endP = startP;
                startP.X = (float)(csPr.X + mv * Math.Cos(Math.Atan2(cePr.Y - csPr.Y, cePr.X - csPr.X)));
                startP.Y = (float)(csPr.Y + mv * Math.Sin(Math.Atan2(cePr.Y - csPr.Y, cePr.X - csPr.X)));
            }
            else
            {
                Prijehal = true;
                mv = 0;
                distance = 0;
                t = true;
            }
        }
    }
}
