﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace proba01
{
    class Metro
    {
        public static Graphics g;
        public Color clr;
        public static Color bclr;
        public static Form1 form;
        Poezd[] poezds = new Poezd[3];
        Point LstP = new Point(0, 0);
        bool delRoute = false;
        Point localFRP, localLRP;
        Point DlocalFRP, DlocalLRP;
        List<Stancija> SList = new List<Stancija>();
        List<Route> RList = new List<Route>();
        Stancija[] stancijasm1 = new Stancija[18];
        Stancija[] stancijasm2 = new Stancija[16];
        Stancija[] stancijasm3 = new Stancija[16];
        //-----------------------------------------------------------------------------------------
        Timer timerRuh = new Timer();
        Timer timerPas = new Timer();
        Timer timerYear = new Timer();
        Label label1 = new Label();
        Label label2 = new Label();
        Label label3 = new Label();
        Button button1 = new Button();
        Button button2 = new Button();
        RadioButton AddRoute =new RadioButton();
        RadioButton DeleteRoute =new RadioButton();
        RadioButton radioButton1 =new RadioButton();
        Panel panel1 = new Panel();
        //-----------------------------------------------------------------------------------------
       public Metro() {
            form.Load += Form1_Load;
            form.MouseDown += Form1_MouseDown;
            form.KeyPreview = true;
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            panel1.Location = new Point(1024, 0);
            panel1.Size = new Size(191, 922);
            panel1.Visible = true;
            panel1.Enabled = true;
            panel1.Dock = DockStyle.Right;
            panel1.BorderStyle = BorderStyle.FixedSingle;
            label1.Location = new Point(0, 150);
            label1.Text = "Назва станції";
            label1.AutoSize = true;
            label1.Visible = true;
            label1.Enabled = true;
            label2.Location = new Point(12, 9);
            label2.Text = "1960";
            label2.AutoSize = true;
            label2.Visible = true;
            label2.Enabled = true;
            label3.Location = new Point(0, 163);
            label3.Text = "Кількість пасажирів";
            label3.AutoSize = true;
            label3.Visible = true;
            label3.Enabled = true;
            button1.Location = new Point(3, 3);
            button1.Text = "ЗАПУСК";
            button1.Size = new Size(183, 23);
            button1.Visible = true;
            button1.Enabled = false;
            button1.Click += button1_Click;
            button2.Location = new Point(3, 55);
            button2.Text = "СТАРТ";
            button2.Size = new Size(183, 23);
            button2.Visible = true;
            button2.Enabled = true;
            button2.Click += button2_Click;
            AddRoute.Location = new Point(3, 84);
            AddRoute.Text = "Додати колії";
            AddRoute.AutoSize = true;
            AddRoute.Visible = true;
            AddRoute.Checked = true;
            AddRoute.Enabled = true;
            AddRoute.CheckedChanged += AddRoute_CheckedChanged;
            DeleteRoute.Location = new Point(3, 107);
            DeleteRoute.Text = "Видалити колії";
            DeleteRoute.AutoSize = true;
            DeleteRoute.Visible = true;
            DeleteRoute.Checked = false;
            DeleteRoute.Enabled = true;
            DeleteRoute.CheckedChanged += DeleteRoute_CheckedChanged;
            radioButton1.Location = new Point(3, 130);
            radioButton1.Text = "Перегляд станції";
            radioButton1.AutoSize = true;
            radioButton1.Visible = true;
            radioButton1.Checked = false;
            radioButton1.Enabled = true;
            timerRuh.Enabled = false;
            timerRuh.Interval = 500;
            timerRuh.Tick += timerRuh_Tick;
            timerYear.Enabled = false;
            timerYear.Interval = 120000;
            timerYear.Tick += timerYear_Tick;
            timerPas.Enabled = false;
            timerPas.Interval = 20000;
            timerPas.Tick += timerPas_Tick;
            panel1.Controls.Add(label1);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(button1);
            panel1.Controls.Add(button2);
            panel1.Controls.Add(AddRoute);
            panel1.Controls.Add(DeleteRoute);
            panel1.Controls.Add(radioButton1);
            form.Controls.Add(panel1);
            form.Controls.Add(label2);
            //----------------------------------------------------------------------------------
            poezds[0] = new Poezd(Color.Red, Color.DarkRed, 0);
            poezds[1] = new Poezd(Color.Blue, Color.DarkBlue, 2);
            poezds[2] = new Poezd(Color.Green, Color.DarkGreen, 1);
            poezds[0].location = new PointF(240, 435);
            poezds[1].location = new PointF(470, 370);
            poezds[2].location = new PointF(455, 525);
            stancijasm1[0] = new Stancija(Color.Red, new Point(34, 190), 2003, "Академмістечко", 101);
            stancijasm1[1] = new Stancija(Color.Red, new Point(35, 235), 2003, "Житомирська", 102);
            stancijasm1[2] = new Stancija(Color.Red, new Point(70, 265), 1971, "Святошино", 103);
            stancijasm1[3] = new Stancija(Color.Red, new Point(105, 300), 1971, "Нивки", 104);
            stancijasm1[4] = new Stancija(Color.Red, new Point(140, 335), 1971, "Берестейська", 105);
            stancijasm1[5] = new Stancija(Color.Red, new Point(170, 365), 1963, "Шулявська", 106);
            stancijasm1[6] = new Stancija(Color.Red, new Point(205, 400), 1963, "Політехнічний Інститут", 107);
            stancijasm1[7] = new Stancija(Color.Red, new Point(240, 435), 1960, "Вокзальна", 108);
            stancijasm1[8] = new Stancija(Color.Red, new Point(300, 435), 1960, "Університет", 109);
            stancijasm1[9] = new StancijaPeresadka(Color.Silver, new Point(360, 435), 1987, "Театральна та Золоті Ворота", 110, Color.Red, Color.Green);
            stancijasm1[9].SvobodSvjaz = 4;
            stancijasm1[10] = new StancijaPeresadka(Color.Silver, new Point(470, 435), 1960, "Хрещатик та Майдан Незалежності", 111, Color.Red, Color.Blue);
            stancijasm1[10].SvobodSvjaz = 4;
            stancijasm1[11] = new Stancija(Color.Red, new Point(540, 435), 1960, "Арсенальна", 112);
            stancijasm1[12] = new Stancija(Color.Red, new Point(605, 500), 1960, "Дніпро", 113);
            stancijasm1[13] = new Stancija(Color.Red, new Point(680, 500), 1965, "Гідропарк", 114);
            stancijasm1[14] = new Stancija(Color.Red, new Point(745, 430), 1965, "Лівобережна", 115);
            stancijasm1[15] = new Stancija(Color.Red, new Point(810, 365), 1965, "Дарниця", 116);
            stancijasm1[16] = new Stancija(Color.Red, new Point(880, 300), 1968, "Чернігівська", 117);
            stancijasm1[17] = new Stancija(Color.Red, new Point(945, 230), 1979, "Лісова", 118);
            stancijasm2[0] = new Stancija(Color.Blue, new Point(470, 110), 1982, "Георїв Дніпра", 201);
            stancijasm2[1] = new Stancija(Color.Blue, new Point(470, 150), 1982, "Мінська", 202);
            stancijasm2[2] = new Stancija(Color.Blue, new Point(470, 200), 1980, "Оболонь", 203);
            stancijasm2[3] = new Stancija(Color.Blue, new Point(470, 240), 1980, "Почайна", 204);
            stancijasm2[4] = new Stancija(Color.Blue, new Point(470, 285), 1980, "Тараса Шевченка", 205);
            stancijasm2[5] = new Stancija(Color.Blue, new Point(470, 330), 1976, "Контрактова Площа", 206);
            stancijasm2[6] = new Stancija(Color.Blue, new Point(470, 370), 1976, "Почтова Площа", 207);
            stancijasm2[7] = new Stancija(Color.Blue, new Point(415, 550), 1981, "Олімпійська", 210);
            stancijasm2[8] = new Stancija(Color.Blue, new Point(415, 605), 1984, "Палац Україна", 211);
            stancijasm2[9] = new Stancija(Color.Blue, new Point(415, 650), 1984, "Либідська", 212);
            stancijasm2[10] = new Stancija(Color.Blue, new Point(375, 690), 2010, "Деміївська", 213);
            stancijasm2[11] = new Stancija(Color.Blue, new Point(335, 730), 2010, "Голосіївська", 214);
            stancijasm2[12] = new Stancija(Color.Blue, new Point(295, 770), 2010, "Васильківська", 215);
            stancijasm2[13] = new Stancija(Color.Blue, new Point(245, 810), 2011, "Виставковий Центр", 216);
            stancijasm2[14] = new Stancija(Color.Blue, new Point(200, 855), 2012, "Іподром", 217);
            stancijasm2[15] = new Stancija(Color.Blue, new Point(120, 856), 2013, "Теремки", 218);
            stancijasm3[0] = new Stancija(Color.Green, new Point(235, 210), 2004, "Сирець", 301);
            stancijasm3[1] = new Stancija(Color.Green, new Point(275, 250), 2000, "Дорогожичі", 302);
            stancijasm3[2] = new Stancija(Color.Green, new Point(315, 290), 1996, "Лук'янівська", 303);
            stancijasm3[3] = new Stancija(Color.Green, new Point(316, 345), 1996, "Львівська Брама", 304);
            stancijasm3[4] = new StancijaPeresadka(Color.Silver, new Point(415, 490), 1989, "Палац Спорту та Площа Льва Толстого", 306, Color.Green, Color.Blue);
            stancijasm3[4].SvobodSvjaz = 4;
            stancijasm3[5] = new Stancija(Color.Green, new Point(455, 525), 1989, "Кловська", 307);
            stancijasm3[6] = new Stancija(Color.Green, new Point(490, 565), 1997, "Печерська", 308);
            stancijasm3[7] = new Stancija(Color.Green, new Point(530, 600), 1991, "Дружби Народів", 309);
            stancijasm3[8] = new Stancija(Color.Green, new Point(565, 640), 1991, "Видубичі", 310);
            stancijasm3[9] = new Stancija(Color.Green, new Point(610, 680), 1992, "Славутич", 311);
            stancijasm3[10] = new Stancija(Color.Green, new Point(715, 680), 1992, "Осокорки", 312);
            stancijasm3[11] = new Stancija(Color.Green, new Point(795, 680), 1994, "Позняки", 313);
            stancijasm3[12] = new Stancija(Color.Green, new Point(865, 680), 1994, "Харківська", 314);
            stancijasm3[13] = new Stancija(Color.Green, new Point(905, 640), 2006, "Вирлиця", 315);
            stancijasm3[14] = new Stancija(Color.Green, new Point(945, 600), 2005, "Бориспільська", 316);
            stancijasm3[15] = new Stancija(Color.Green, new Point(985, 560), 2008, "Червоний Хутір", 317);
        }
        private void timerRuh_Tick(object sender, EventArgs e)
        {
            RukhPotagiv(poezds[0]);
            if (rik > 1976)
            {
                RukhPotagiv(poezds[1]);
            }
            if (rik > 1989)
            {
                RukhPotagiv(poezds[2]);
            }
        }
        int rik = 1960;
        Stancija TempSt;
        int countVisad;
        int countPosad;
        void RukhPotagiv(Poezd p)
        {
            if (p.Prijehal == true)
            {
                TempSt = SList.Find(s => s.p.X == p.location.X && s.p.Y == p.location.Y);
                if (TempSt != null)
                {
                    bool b1 = (TempSt.type == "Peresadka") ? true : false;
                    if ((b1 == false && (TempSt.roudVpered != null || TempSt.roudNazad != null)) || (b1 == true && (((StancijaPeresadka)TempSt).r[0, p.index] != null || (((StancijaPeresadka)TempSt).r[1, p.index] != null))))
                    {
                        countVisad = p.passengers;
                        if (TempSt.passangers <= 5)
                        {
                            countPosad = TempSt.passangers;
                        }
                        else if (TempSt.passangers < 10)
                        {
                            countPosad = rand.Next(5, 9);
                        }
                        else if (TempSt.passangers < 15)
                        {
                            countPosad = rand.Next(10, 15);
                        }
                        else
                        {
                            countPosad = 15;
                        }

                        if (!p.jezdanazd)
                        {
                            p.Prijehal = false;
                            p.t = true;
                            if (TempSt.type == "Standart")
                            {
                                if (TempSt.roudVpered != null)
                                {
                                    p.points[0] = TempSt.roudVpered.FRP;
                                    p.points[1] = TempSt.roudVpered.LRP;
                                }
                                else
                                {
                                    p.jezdanazd = true;
                                    p.points[0] = TempSt.roudNazad.FRP;
                                    p.points[1] = TempSt.roudNazad.LRP;
                                }
                            }
                            else
                            {
                                if (((StancijaPeresadka)TempSt).r[0, p.index] != null)
                                {
                                    p.points[0] = ((StancijaPeresadka)TempSt).r[0, p.index].FRP;
                                    p.points[1] = ((StancijaPeresadka)TempSt).r[0, p.index].LRP;
                                }
                                else
                                {
                                    p.jezdanazd = true;
                                    p.points[0] = ((StancijaPeresadka)TempSt).r[1, p.index].FRP;
                                    p.points[1] = ((StancijaPeresadka)TempSt).r[1, p.index].LRP;
                                }
                            }
                            p.passengers -= countVisad;
                            if (p.passengers + countPosad <= 15 && TempSt.passangers - countPosad >= 0)//Пасажирі
                            {
                                p.passengers += countPosad;
                                TempSt.passangers -= countPosad;
                            }
                        }
                        else if (p.jezdanazd)
                        {
                            p.Prijehal = false;
                            p.t = true;
                            if (TempSt.type == "Standart")
                            {
                                if (TempSt.roudNazad != null)
                                {
                                    p.points[0] = TempSt.roudNazad.FRP;
                                    p.points[1] = TempSt.roudNazad.LRP;
                                }
                                else
                                {
                                    p.jezdanazd = false;
                                    p.points[0] = TempSt.roudVpered.FRP;
                                    p.points[1] = TempSt.roudVpered.LRP;
                                }
                            }
                            else
                            {
                                if (((StancijaPeresadka)TempSt).r[1, p.index] != null)
                                {
                                    p.points[0] = ((StancijaPeresadka)TempSt).r[1, p.index].FRP;
                                    p.points[1] = ((StancijaPeresadka)TempSt).r[1, p.index].LRP;
                                }
                                else
                                {
                                    p.jezdanazd = false;
                                    p.points[0] = ((StancijaPeresadka)TempSt).r[0, p.index].FRP;
                                    p.points[1] = ((StancijaPeresadka)TempSt).r[0, p.index].LRP;
                                }
                            }
                            p.passengers -= countVisad;
                            if (p.passengers + countPosad <= 15 && TempSt.passangers - countPosad >= 0)
                            {
                                p.passengers += countPosad;
                                TempSt.passangers -= countPosad;
                            }
                        }
                    }
                }
            }
            if (!p.Prijehal)
            {
                p.draw(p.points[0], p.points[1]);
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            timerRuh.Enabled = !timerRuh.Enabled;
            timerPas.Enabled = !timerPas.Enabled;
            if (timerRuh.Enabled == true)
            {
                button1.Text = "ЗУПИНКА";
            }
            else
            {
                button1.Text = "ЗАПУСК";
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            timerYear.Enabled = !timerYear.Enabled;
            if (timerYear.Enabled == true)
            {
                button2.Text = "СТОП";
                button1.Enabled = true;
            }
            else
            {
                button1.Enabled = false;
                button2.Text = "ПРОДОВЖИТИ";
                button1.Text = "ЗАПУСК";
                timerRuh.Enabled = false;
                timerPas.Enabled = false;
            }
            if (rik == 1960)
            {
                for (int i = 0; i < stancijasm1.Length; i++)
                {
                    if (rik == stancijasm1[i].godvod)
                    {
                        stancijasm1[i].draw();
                        SList.Add(stancijasm1[i]);
                    }
                }
                rik++;
                label2.Text = rik.ToString();
            }
        }
        private void AddRoute_CheckedChanged(object sender, EventArgs e)
        {
            delRoute = false;
        }
        private void DeleteRoute_CheckedChanged(object sender, EventArgs e)
        {
            delRoute = true;
        }
        private void timerYear_Tick(object sender, EventArgs e)
        {
            if (rik < 2024)
            {
                for (int i = 0; i < stancijasm1.Length; i++)
                {
                    if (rik + 1 == stancijasm1[i].godvod)
                    {
                        stancijasm1[i].draw();
                        SList.Add(stancijasm1[i]);
                    }
                }
                for (int i = 0; i < stancijasm2.Length; i++)
                {
                    if (rik + 1 == stancijasm2[i].godvod)
                    {
                        stancijasm2[i].draw();
                        SList.Add(stancijasm2[i]);
                    }
                }
                for (int i = 0; i < stancijasm3.Length; i++)
                {
                    if (rik + 1 == stancijasm3[i].godvod)
                    {
                        stancijasm3[i].draw();
                        SList.Add(stancijasm3[i]);
                    }
                }
                rik++;
                label2.Text = rik.ToString();
            }
            else
            {
                timerYear.Enabled = false;
                MessageBox.Show("ВИ ПЕРЕМОГЛИ!!!");
                Environment.Exit(0);
            }
        }
        Random rand = new Random();
        bool stp = false;
        private void timerPas_Tick(object sender, EventArgs e)
        {
            for (int i = 0; i < SList.Count; i++)
            {
                SList[i].passangers += rand.Next(1, 5);
                if (SList[i].passangers>150 && !stp)
                {
                    stp = true;
                    timerRuh.Enabled = false;
                    timerYear.Enabled = false;
                    MessageBox.Show("ВИ ПРОГРАЛИ :(");
                    Environment.Exit(0);
                }
            }
        }
        bool b = false;
        bool bb = false;
        int sw;
        int c1;
        void Deletor(Point LFpr, Point LLpr)
        {
            Stancija tempSt1 = SList.Find(s => s.p.X == LFpr.X && s.p.Y == LFpr.Y);
            Stancija tempSt2 = SList.Find(s => s.p.X == LLpr.X && s.p.Y == LLpr.Y);
            if ((tempSt1.clr == Color.Silver && tempSt2.clr == Color.Red || tempSt1.clr == Color.Red && tempSt2.clr == Color.Silver
               || tempSt1.clr == Color.Red && tempSt2.clr == Color.Red) || (tempSt1.clr == Color.Silver && tempSt2.clr == Color.Green
               || tempSt1.clr == Color.Green && tempSt2.clr == Color.Silver || tempSt1.clr == Color.Green && tempSt2.clr == Color.Green))
            {
                if (DlocalFRP.X < DlocalLRP.X)
                {
                    if (tempSt1.clr != Color.Silver && tempSt2.clr != Color.Silver)
                    {
                        tempSt1.roudVpered = null;
                        tempSt2.roudNazad = null;
                    }
                    else if (tempSt1.clr == Color.Silver)
                    {
                        c1 = (tempSt2.clr == Color.Red) ? 0 : 1;
                        ((StancijaPeresadka)tempSt1).r[0, c1] = null;
                        tempSt2.roudNazad = null;
                    }
                    else if (tempSt2.clr == Color.Silver)
                    {
                        c1 = (tempSt1.clr == Color.Red) ? 0 : 1;
                        tempSt1.roudVpered = null;
                        ((StancijaPeresadka)tempSt2).r[1, c1] = null;
                    }
                }
                else if (DlocalFRP.X > DlocalLRP.X)
                {
                    if (tempSt1.clr != Color.Silver && tempSt2.clr != Color.Silver)
                    {
                        tempSt2.roudVpered = null;
                        tempSt1.roudNazad = null;
                    }
                    else if (tempSt1.clr == Color.Silver)
                    {
                        c1 = (tempSt2.clr == Color.Red) ? 0 : 1;
                        tempSt2.roudVpered = null;
                        ((StancijaPeresadka)tempSt1).r[1, c1] = null;
                    }
                    else if (tempSt2.clr == Color.Silver)
                    {
                        c1 = (tempSt1.clr == Color.Red) ? 0 : 1;
                        ((StancijaPeresadka)tempSt2).r[0, c1] = null;
                        tempSt1.roudNazad = null;
                    }
                }
            }
            if (tempSt1.clr == Color.Silver && tempSt2.clr == Color.Blue || tempSt1.clr == Color.Blue && tempSt2.clr == Color.Silver
                            || tempSt1.clr == Color.Blue && tempSt2.clr == Color.Blue)
            {
                if (DlocalFRP.Y < DlocalLRP.Y)
                {
                    if (tempSt1.clr != Color.Silver && tempSt2.clr != Color.Silver)
                    {
                        tempSt1.roudVpered = null;
                        tempSt2.roudNazad = null;
                    }
                    else if (tempSt1.clr == Color.Silver)
                    {
                        ((StancijaPeresadka)tempSt1).r[0, 2] = null;
                        tempSt2.roudNazad = null;
                    }
                    else if (tempSt2.clr == Color.Silver)
                    {
                        tempSt1.roudVpered = null;
                        ((StancijaPeresadka)tempSt2).r[1, 2] = null;
                    }
                }
                else if (DlocalFRP.Y > DlocalLRP.Y)
                {
                    if (tempSt1.clr != Color.Silver && tempSt2.clr != Color.Silver)
                    {
                        tempSt2.roudVpered = null;
                        tempSt1.roudNazad = null;
                    }
                    else if (tempSt1.clr == Color.Silver)
                    {
                        tempSt2.roudVpered = null;
                        ((StancijaPeresadka)tempSt1).r[1, 2] = null;
                    }
                    else if (tempSt2.clr == Color.Silver)
                    {
                        ((StancijaPeresadka)tempSt2).r[0, 2] = null;
                        tempSt1.roudNazad = null;
                    }
                }
            }
            if (tempSt1.clr == Color.Silver && tempSt2.clr == Color.Silver)
            {
                SwichColor f = new SwichColor();
                f.panel1.BackColor = ((StancijaPeresadka)tempSt2).Linecolor1;
                f.panel2.BackColor = ((StancijaPeresadka)tempSt2).Linecolor2;
                f.ShowDialog();
                switch (f.SelectedColor.ToArgb().ToString())
                {
                    case "-65536": sw = 0; break;
                    case "-16744448": sw = 1; break;
                    case "-16776961": sw = 2; break;
                }
                if (sw != 2)
                {
                    if (DlocalFRP.X < DlocalLRP.X)
                    {
                        ((StancijaPeresadka)tempSt1).r[0, sw] = null;
                        ((StancijaPeresadka)tempSt2).r[1, sw] = null;
                    }
                    else if (DlocalFRP.X > DlocalLRP.X)
                    {
                        ((StancijaPeresadka)tempSt2).r[0, sw] = null;
                        ((StancijaPeresadka)tempSt1).r[1, sw] = null;
                    }
                }
                else
                {
                    if (DlocalFRP.Y < DlocalLRP.Y)
                    {
                        ((StancijaPeresadka)tempSt1).r[0, sw] = null;
                        ((StancijaPeresadka)tempSt2).r[1, sw] = null;
                    }
                    else if (DlocalFRP.Y > DlocalLRP.Y)
                    {
                        ((StancijaPeresadka)tempSt2).r[0, sw] = null;
                        ((StancijaPeresadka)tempSt1).r[1, sw] = null;
                    }
                }
            }
        }
        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            int c = 0;
            for (int i = 0; i < SList.Count; i++)
            {
                if (SList[i].p.X < e.X && SList[i].size.Width + SList[i].p.X > e.X && SList[i].p.Y < e.Y && SList[i].size.Height + SList[i].p.Y > e.Y)
                {
                    MessageBox.Show($"Станція {SList[i].caption} обрана! " + SList[i].p.X + " " + SList[i].p.Y);
                    SList[i].draw();
                    if (radioButton1.Checked)
                    {
                        label1.Text = SList[i].caption;
                        label3.Text = "К-сть пасажирів: " + SList[i].passangers.ToString();
                    }
                    if (!b && SList[i].SvobodSvjaz > 0 && !delRoute && !radioButton1.Checked)
                    {
                        localFRP = new Point(SList[i].p.X, SList[i].p.Y);
                        SList[i].SvobodSvjaz--;
                        SList[i].oborot = false;
                        b = true;
                    }
                    else if (b && SList[i].SvobodSvjaz > 0 && !delRoute && !radioButton1.Checked)
                    {
                        localLRP = new Point(SList[i].p.X, SList[i].p.Y);
                        //Для додавання
                        Stancija tempSt1 = SList.Find(s => s.p.X == localFRP.X && s.p.Y == localFRP.Y);
                        Stancija tempSt2 = SList.Find(s => s.p.X == localLRP.X && s.p.Y == localLRP.Y);
                        if ((tempSt1.clr == Color.Silver && tempSt2.clr == Color.Red || tempSt1.clr == Color.Red && tempSt2.clr == Color.Silver
                            || tempSt1.clr == Color.Red && tempSt2.clr == Color.Red) || (tempSt1.clr == Color.Silver && tempSt2.clr == Color.Green
                            || tempSt1.clr == Color.Green && tempSt2.clr == Color.Silver || tempSt1.clr == Color.Green && tempSt2.clr == Color.Green))
                        {
                            if (localFRP.X < localLRP.X)
                            {
                                if (tempSt1.clr != Color.Silver && tempSt2.clr != Color.Silver)
                                {
                                    RList.Add(new Route(localFRP, localLRP));
                                    tempSt1.roudVpered = new Route(localFRP, localLRP);
                                    tempSt2.roudNazad = new Route(localLRP, localFRP);
                                    RList[RList.Count - 1].clr = Color.Brown;
                                }
                                else if (tempSt1.clr == Color.Silver)
                                {
                                    c = (tempSt2.clr == Color.Red) ? 0 : 1;
                                    ((StancijaPeresadka)tempSt1).r[0, c] = new Route(localFRP, localLRP);
                                    tempSt2.roudNazad = new Route(localLRP, localFRP);
                                    RList.Add(new Route(localFRP, localLRP));
                                    RList[RList.Count - 1].clr = Color.Brown;
                                }
                                else if (tempSt2.clr == Color.Silver)
                                {
                                    c = (tempSt1.clr == Color.Red) ? 0 : 1;
                                    tempSt1.roudVpered = new Route(localFRP, localLRP);
                                    ((StancijaPeresadka)tempSt2).r[1, c] = new Route(localLRP, localFRP);
                                    RList.Add(new Route(localFRP, localLRP));
                                    RList[RList.Count - 1].clr = Color.Brown;
                                }
                            }
                            else if (localFRP.X > localLRP.X)
                            {
                                if (tempSt1.clr != Color.Silver && tempSt2.clr != Color.Silver)
                                {
                                    RList.Add(new Route(localLRP, localFRP));
                                    tempSt2.roudVpered = new Route(localLRP, localFRP);
                                    tempSt1.roudNazad = new Route(localFRP, localLRP);
                                    RList[RList.Count - 1].clr = Color.Brown;
                                }
                                else if (tempSt1.clr == Color.Silver)
                                {
                                    c = (tempSt2.clr == Color.Red) ? 0 : 1;
                                    RList.Add(new Route(localLRP, localFRP));
                                    tempSt2.roudVpered = new Route(localLRP, localFRP);
                                    ((StancijaPeresadka)tempSt1).r[1, c] = new Route(localFRP, localLRP);
                                    RList[RList.Count - 1].clr = Color.Brown;
                                }
                                else if (tempSt2.clr == Color.Silver)
                                {
                                    c = (tempSt1.clr == Color.Red) ? 0 : 1;
                                    RList.Add(new Route(localLRP, localFRP));
                                    ((StancijaPeresadka)tempSt2).r[0, c] = new Route(localLRP, localFRP);
                                    tempSt1.roudNazad = new Route(localFRP, localLRP);
                                    RList[RList.Count - 1].clr = Color.Brown;
                                }
                            }
                        }
                        if (tempSt1.clr == Color.Silver && tempSt2.clr == Color.Blue || tempSt1.clr == Color.Blue && tempSt2.clr == Color.Silver
                           || tempSt1.clr == Color.Blue && tempSt2.clr == Color.Blue)
                        {
                            if (localFRP.Y < localLRP.Y)
                            {
                                if (tempSt1.clr != Color.Silver && tempSt2.clr != Color.Silver)
                                {
                                    RList.Add(new Route(localFRP, localLRP));
                                    tempSt1.roudVpered = new Route(localFRP, localLRP);
                                    tempSt2.roudNazad = new Route(localLRP, localFRP);
                                    RList[RList.Count - 1].clr = Color.Brown;
                                }
                                else if (tempSt1.clr == Color.Silver)
                                {
                                    ((StancijaPeresadka)tempSt1).r[0, 2] = new Route(localFRP, localLRP);
                                    tempSt2.roudNazad = new Route(localLRP, localFRP);
                                    RList.Add(new Route(localFRP, localLRP));
                                    RList[RList.Count - 1].clr = Color.Brown;
                                }
                                else if (tempSt2.clr == Color.Silver)
                                {
                                    tempSt1.roudVpered = new Route(localFRP, localLRP);
                                    ((StancijaPeresadka)tempSt2).r[1, 2] = new Route(localLRP, localFRP);
                                    RList.Add(new Route(localFRP, localLRP));
                                    RList[RList.Count - 1].clr = Color.Brown;
                                }
                            }
                            else if (localFRP.Y > localLRP.Y)
                            {
                                if (tempSt1.clr != Color.Silver && tempSt2.clr != Color.Silver)
                                {
                                    RList.Add(new Route(localLRP, localFRP));
                                    tempSt2.roudVpered = new Route(localLRP, localFRP);
                                    tempSt1.roudNazad = new Route(localFRP, localLRP);
                                    RList[RList.Count - 1].clr = Color.Brown;
                                }
                                else if (tempSt1.clr == Color.Silver)
                                {
                                    tempSt2.roudVpered = new Route(localLRP, localFRP);
                                    ((StancijaPeresadka)tempSt1).r[1, 2] = new Route(localFRP, localLRP);
                                    RList.Add(new Route(localLRP, localFRP));
                                    RList[RList.Count - 1].clr = Color.Brown;
                                }
                                else if (tempSt2.clr == Color.Silver)
                                {
                                    ((StancijaPeresadka)tempSt2).r[0, 2] = new Route(localLRP, localFRP);
                                    tempSt1.roudNazad = new Route(localFRP, localLRP);
                                    RList.Add(new Route(localLRP, localFRP));
                                    RList[RList.Count - 1].clr = Color.Brown;
                                }
                            }
                        }
                        int col = 0;
                        if (tempSt1.clr == Color.Silver && tempSt2.clr == Color.Silver)
                        {
                            SwichColor f = new SwichColor();
                            f.panel1.BackColor = ((StancijaPeresadka)tempSt2).Linecolor1;
                            f.panel2.BackColor = ((StancijaPeresadka)tempSt2).Linecolor2;
                            f.ShowDialog();
                            switch (f.SelectedColor.ToArgb().ToString())
                            {
                                case "-65536": col = 0; break;
                                case "-16744448": col = 1; break;
                                case "-16776961": col = 2; break;
                            }
                            if (col != 2)
                            {
                                if (localFRP.X < localLRP.X)
                                {
                                    RList.Add(new Route(localFRP, localLRP));
                                    ((StancijaPeresadka)tempSt1).r[0, col] = new Route(localFRP, localLRP);
                                    ((StancijaPeresadka)tempSt2).r[1, col] = new Route(localLRP, localFRP);
                                    RList[RList.Count - 1].clr = Color.Green;
                                }
                                else if (localFRP.X > localLRP.X)
                                {
                                    RList.Add(new Route(localLRP, localFRP));
                                    ((StancijaPeresadka)tempSt2).r[0, col] = new Route(localLRP, localFRP);
                                    ((StancijaPeresadka)tempSt1).r[1, col] = new Route(localFRP, localLRP);
                                    RList[RList.Count - 1].clr = Color.Orange;
                                }
                            }
                            else
                            {
                                if (localFRP.Y < localLRP.Y)
                                {
                                    RList.Add(new Route(localFRP, localLRP));
                                    ((StancijaPeresadka)tempSt1).r[0, col] = new Route(localFRP, localLRP);
                                    ((StancijaPeresadka)tempSt2).r[1, col] = new Route(localLRP, localFRP);
                                    RList[RList.Count - 1].clr = Color.Green;
                                }
                                else if (localFRP.Y > localLRP.Y)
                                {
                                    RList.Add(new Route(localLRP, localFRP));
                                    ((StancijaPeresadka)tempSt2).r[0, col] = new Route(localLRP, localFRP);
                                    ((StancijaPeresadka)tempSt1).r[1, col] = new Route(localFRP, localLRP);
                                    RList[RList.Count - 1].clr = Color.Orange;
                                }
                            }
                        }
                        RList[RList.Count - 1].draw();
                        SList[i].SvobodSvjaz--;
                        b = false;
                        localFRP = new Point(0, 0);
                        localLRP = new Point(0, 0);
                    }
                    //Для видалення
                    if (!bb && delRoute && !radioButton1.Checked)
                    {
                        DlocalFRP = new Point(SList[i].p.X, SList[i].p.Y);
                        SList[i].SvobodSvjaz++;
                        SList[i].oborot = true;
                        bb = true;
                    }
                    else if (bb && delRoute && !radioButton1.Checked)
                    {
                        DlocalLRP = new Point(SList[i].p.X, SList[i].p.Y);
                        Deletor(DlocalFRP, DlocalLRP);
                        RList.Remove(RList.Find(r => r.FRP == DlocalFRP && r.LRP == DlocalLRP));
                        SList[i].SvobodSvjaz++;
                        Metro.g.DrawLine(new Pen(Metro.bclr), DlocalFRP, DlocalLRP);
                        DlocalFRP = new Point(0, 0);
                        DlocalLRP = new Point(0, 0);
                        SList[i].oborot = true;
                        bb = false;
                    }
                }
            }
        }
    }
}