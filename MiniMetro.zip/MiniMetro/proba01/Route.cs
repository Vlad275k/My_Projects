﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace proba01
{
    class Route: Metro
    {
        public Point FRP, LRP;
        public Route(Point F, Point L)
        {
            FRP = F;
            LRP = L;
        }
        public void draw()
        {
            g.DrawLine(new Pen(clr), FRP, LRP);
        }
    }
}
