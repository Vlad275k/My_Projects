﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace proba01
{
    public partial class SwichColor : Form
    {
        public SwichColor()
        {
            InitializeComponent();
        }
        public Color SelectedColor;

        private void panel1_Click(object sender, EventArgs e)
        {
            SelectedColor = panel1.BackColor;
            DialogResult = DialogResult.OK;
        }

        private void panel2_Click(object sender, EventArgs e)
        {
            SelectedColor = panel2.BackColor;
            DialogResult = DialogResult.OK;
        }
    }
}
