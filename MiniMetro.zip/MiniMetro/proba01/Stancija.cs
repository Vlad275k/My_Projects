﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace proba01
{
    class Stancija : Metro
    {
        public string type;
        public int passangers;
        protected int mcP = 16;
        public bool oborot = false;
        public Size size;
        public Point p;
        public byte SvobodSvjaz = 2;
        public int godvod;
        protected int index;
        public string caption;
        public Route roudVpered;
        public Route roudNazad;
        public Stancija(Color scolor, Point pS, int gv, string name, int iX)
        {
            type = "Standart";
            godvod = gv;
            clr = scolor;
            size = new Size(20, 20);
            p = pS;
            caption = name;
            index = iX;
        }
        public void draw()
        {
            g.DrawEllipse(new Pen(clr, 3), p.X - 10, p.Y - 10, size.Width, size.Height);
        }
    }
    class StancijaPeresadka : Stancija
    {
        public Color Linecolor1, Linecolor2;
        public Route[,] r = new Route[2,3];
        public StancijaPeresadka(Color scolor, Point pS, int gv, string name, int iX, Color cr1, Color cr2) : base(scolor, pS, gv, name, iX)
        {
            type = "Peresadka";
            Linecolor1 = cr1;
            Linecolor2=cr2;
            godvod = gv;
            clr = scolor;
            size = new Size(20, 20);
            p = pS;
            caption = name;
            index = iX;
        }
       
    }
}
